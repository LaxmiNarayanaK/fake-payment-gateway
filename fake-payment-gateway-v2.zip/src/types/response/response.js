function Response()
{
    this.success = false;
    this.message = '';
    this.data = {};
}

module.exports = Response;
