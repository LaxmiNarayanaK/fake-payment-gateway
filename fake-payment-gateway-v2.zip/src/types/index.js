const Card = require('./card/card.js');
const Phone = require('./phone/phone.js');
const Response = require('./response/response');

module.exports = {
    Card,
    Phone,
    Response,
};
